package nl.teamdiopside.diopside.fabric.config;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import nl.teamdiopside.diopside.config.DiopsideConfig;

public class DiopsideModMenu implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parentScreen -> DiopsideConfig.HANDLER.instance().generateScreen(parentScreen);
    }
}
